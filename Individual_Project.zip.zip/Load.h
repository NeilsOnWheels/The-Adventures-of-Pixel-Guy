// Load.h - class that loads all pictures and sprites
// Written by Neil Casey

#pragma once;

#include "DarkGDK.h"
#include "Variables.h"

class Loader
{
public:
	void LoadImages();
};