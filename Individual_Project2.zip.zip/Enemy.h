// Enemy.h - Enemy class definition
// Written by Neil Casey

#pragma once

#include "DarkGDK.h"
#include "Variables.h"

using namespace std;

class Enemy 
{
public:
	// data members:
	bool facingRight;
	bool movingRight;
	
	// Init constuctor
	// Need to supply a sprite ID number
	// and x and y spawn coordinates
	Enemy(int enemyID, int xSpawn, int ySpawn);

	void Movement(int id);

};